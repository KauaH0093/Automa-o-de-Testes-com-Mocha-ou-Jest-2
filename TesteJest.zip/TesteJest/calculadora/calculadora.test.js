const Calculadora = require('./calculadora');  

describe('Testes da Calculadora', () => {  
    let calc;  

    beforeEach(() => {  
        calc = new Calculadora();  
    });  

    test('soma de 1 e 2 deve retornar 3', () => {  
        expect(calc.soma(1, 2)).toBe(3);  
    });  

    test('subtração de 5 e 3 deve retornar 2', () => {  
        expect(calc.subtracao(5, 3)).toBe(2);  
    });  

    test('multiplicação de 4 e 5 deve retornar 20', () => {  
        expect(calc.multiplicacao(4, 5)).toBe(20);  
    });  

    test('divisão de 10 por 2 deve retornar 5', () => {  
        expect(calc.divisao(10, 2)).toBe(5);  
    });  

    test('divisão por zero deve lançar erro', () => {  
        expect(() => calc.divisao(10, 0)).toThrow("Divisão por zero");  
    });  
});