# Calculadora Simples  

Esta é uma aplicação simples de calculadora com funcionalidades de soma, subtração, multiplicação e divisão.  

## Instalação  

Para instalar as dependências, execute o comando:  

```bash  
npm install jest --save-dev